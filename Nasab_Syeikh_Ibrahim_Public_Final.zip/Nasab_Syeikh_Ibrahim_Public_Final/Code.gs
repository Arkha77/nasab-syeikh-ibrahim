/**
 * ARKHA FAMILY HERITAGE V2 - GOOGLE APPS SCRIPT BACKEND
 *
 * Cara pakai yang direkomendasikan:
 * 1. Buat Google Spreadsheet baru.
 * 2. Extensions > Apps Script.
 * 3. Tempel Code.gs ini.
 * 4. Buat file HTML bernama index dan tempel index.html dari paket V2.
 * 5. Ubah ADMIN_PIN dan ACCESS_TOKEN.
 * 6. Deploy > New deployment > Web app.
 * 7. Execute as: Me.
 * 8. Untuk keluarga, gunakan akses sesuai kebijakan akun/domain. Jangan membagikan PIN.
 */
const SPREADSHEET_ID = ''; // Kosong jika script terikat langsung pada spreadsheet.
const ACCESS_TOKEN = 'GANTI_TOKEN_API';
const ADMIN_PIN = 'GANTI_PIN_ADMIN';

function doGet(e) {
  if (e && e.parameter && e.parameter.api === '1') {
    try {
      auth_(e.parameter.t || '');
      ensureSheets_();
      return json_(loadData_());
    } catch (err) {
      return json_({ok:false, error:String(err.message || err)});
    }
  }
  return HtmlService.createHtmlOutputFromFile('index')
    .setTitle('Nasab Syeikh Ibrahim')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function doPost(e) {
  try {
    const body = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    auth_(body.token || (e.parameter && e.parameter.t) || '');
    ensureSheets_();
    if (body.action === 'save') {
      saveData_(body.members || [], body.events || [], body.gallery || []);
      return json_({ok:true, savedAt:new Date().toISOString(), members:(body.members||[]).length, events:(body.events||[]).length, gallery:(body.gallery||[]).length});
    }
    return json_({ok:false,error:'Action tidak dikenali.'});
  } catch (err) {
    return json_({ok:false,error:String(err.message || err)});
  }
}

function getSS_() {
  return SPREADSHEET_ID ? SpreadsheetApp.openById(SPREADSHEET_ID) : SpreadsheetApp.getActiveSpreadsheet();
}


function hashPin_(pin) {
  const bytes = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, String(pin || ''), Utilities.Charset.UTF_8);
  return bytes.map(b => (b < 0 ? b + 256 : b).toString(16).padStart(2,'0')).join('');
}
function adminSheet_() {
  const ss=getSS_();
  let sh=ss.getSheetByName('Admins');
  if(!sh) sh=ss.insertSheet('Admins');
  if(sh.getLastRow()===0) sh.getRange(1,1,1,4).setValues([['id','name','pin_hash','created_at']]);
  sh.setFrozenRows(1); return sh;
}
function verifyAdminPin_(pin) {
  if (String(pin||'')===String(ADMIN_PIN) && ADMIN_PIN!=='GANTI_PIN_ADMIN') return true;
  const sh=adminSheet_(); if(sh.getLastRow()<2) return false;
  const hash=hashPin_(pin); return sh.getRange(2,3,sh.getLastRow()-1,1).getValues().some(r=>String(r[0])===hash);
}

function uploadImage(args) {
  const dataUrl=String(args && args.dataUrl || '');
  if(!dataUrl.startsWith('data:image/')) throw new Error('Format foto tidak valid.');
  const m=dataUrl.match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/);
  if(!m) throw new Error('Data foto tidak valid.');
  const bytes=Utilities.base64Decode(m[2]);
  if(bytes.length>2*1024*1024) throw new Error('Foto maksimal 2 MB.');
  const mime=MimeType.JPEG;
  const folderName='Nasab Syeikh Ibrahim Photos';
  const it=DriveApp.getFoldersByName(folderName); const folder=it.hasNext()?it.next():DriveApp.createFolder(folderName);
  const blob=Utilities.newBlob(bytes,mime,(String(args.name||'family-photo').replace(/[^a-zA-Z0-9 _-]/g,'_')+'.jpg'));
  const file=folder.createFile(blob);
  try{file.setSharing(DriveApp.Access.ANYONE_WITH_LINK,DriveApp.Permission.VIEW);}catch(e){}
  return {ok:true,id:file.getId(),url:'https://drive.google.com/uc?export=view&id='+file.getId()};
}
function deleteImage(args) {
  if(!verifyAdminPin_(args && args.pin)) throw new Error('PIN admin tidak valid.');
  const id=String(args && args.fileId || ''); if(!id) throw new Error('ID foto tidak ada.');
  const file=DriveApp.getFileById(id); file.setTrashed(true); return {ok:true};
}

function listAdmins(args) {
  if(!verifyAdminPin_(args && args.pin)) throw new Error('PIN admin tidak valid.');
  const sh=adminSheet_(); if(sh.getLastRow()<2) return [];
  return sh.getRange(2,1,sh.getLastRow()-1,2).getValues().filter(r=>r[0]).map(r=>({id:String(r[0]),name:String(r[1])}));
}
function addAdmin(args) {
  if(!verifyAdminPin_(args && args.pin)) throw new Error('PIN admin saat ini tidak valid.');
  const name=String(args.name||'').trim(), newPin=String(args.newPin||'').trim();
  if(!name || newPin.length<6) throw new Error('Nama wajib diisi dan PIN baru minimal 6 digit.');
  const sh=adminSheet_(); sh.appendRow(['adm_'+Date.now(),name,hashPin_(newPin),new Date()]);
  return {ok:true};
}
function removeAdmin(args) {
  if(!verifyAdminPin_(args && args.pin)) throw new Error('PIN admin tidak valid.');
  const id=String(args.id||''); const sh=adminSheet_(); if(sh.getLastRow()<2) return {ok:true};
  const vals=sh.getRange(2,1,sh.getLastRow()-1,1).getValues();
  for(let i=0;i<vals.length;i++){if(String(vals[i][0])===id){sh.deleteRow(i+2);break;}}
  return {ok:true};
}

function verifyAdmin(args) {
  args = args || {};
  return verifyAdminPin_(args.pin);
}

function loadData(args) {
  auth_(args && args.token);
  ensureSheets_();
  return loadData_();
}

function saveData(args) {
  auth_(args && args.token);
  ensureSheets_();
  const payload = args && args.payload ? args.payload : {};
  saveData_(payload.members || [], payload.events || [], payload.gallery || []);
  return {ok:true, savedAt:new Date().toISOString(), members:(payload.members||[]).length, events:(payload.events||[]).length, gallery:(payload.gallery||[]).length};
}

function auth_(token) {
  if (!ACCESS_TOKEN || ACCESS_TOKEN === 'GANTI_TOKEN_API') throw new Error('ACCESS_TOKEN belum diganti di Code.gs.');
  if (String(token || '') !== String(ACCESS_TOKEN)) throw new Error('Token akses tidak valid.');
}

function ensureSheets_() {
  const ss = getSS_();
  ensureSheet_(ss, 'Members', ['id','name','parent','spouse','gender','status','birth','death','birthPlace','place','occupation','notes','tone','branch','photo','photoId']);
  ensureSheet_(ss, 'Events', ['id','date','title','memberId','notes']);
  ensureSheet_(ss, 'Gallery', ['id','url','caption','memberId']);
  ensureSheet_(ss, 'Settings', ['key','value']);
  adminSheet_();
}

function ensureSheet_(ss, name, headers) {
  let sh = ss.getSheetByName(name);
  if (!sh) sh = ss.insertSheet(name);
  if (sh.getLastRow() === 0) sh.getRange(1,1,1,headers.length).setValues([headers]);
  sh.setFrozenRows(1);
  return sh;
}

function loadData_() {
  const ss = getSS_();
  return {
    ok:true,
    members:readObjects_(ss.getSheetByName('Members')),
    events:readObjects_(ss.getSheetByName('Events')),
    gallery:readObjects_(ss.getSheetByName('Gallery'))
  };
}

function readObjects_(sh) {
  if (!sh || sh.getLastRow() < 2) return [];
  const values = sh.getRange(1,1,sh.getLastRow(),sh.getLastColumn()).getValues();
  const headers = values.shift().map(String);
  return values.filter(row => row.some(v => v !== '')).map(row => {
    const o = {};
    headers.forEach((h,i) => { o[h] = row[i] === '' ? null : row[i]; });
    return o;
  });
}

function saveData_(members, events, gallery) {
  const ss = getSS_();
  writeObjects_(ss.getSheetByName('Members'), members, ['id','name','parent','spouse','gender','status','birth','death','birthPlace','place','occupation','notes','tone','branch','photo','photoId']);
  writeObjects_(ss.getSheetByName('Events'), events, ['id','date','title','memberId','notes']);
  writeObjects_(ss.getSheetByName('Gallery'), gallery, ['id','url','caption','memberId']);
  PropertiesService.getScriptProperties().setProperty('LAST_SYNC', new Date().toISOString());
}

function writeObjects_(sh, rows, headers) {
  sh.clearContents();
  sh.getRange(1,1,1,headers.length).setValues([headers]);
  if (!rows.length) return;
  const values = rows.map(r => headers.map(h => r[h] == null ? '' : r[h]));
  sh.getRange(2,1,values.length,headers.length).setValues(values);
  sh.setFrozenRows(1);
  sh.autoResizeColumns(1, headers.length);
}

function json_(obj) { return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON); }
