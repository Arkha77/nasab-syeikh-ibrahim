NASAB SYEIKH IBRAHIM — PAKET WEBSITE PUBLIK

ISI PAKET
- index.html                         Website utama
- silsilah-referensi.jpeg            Gambar referensi silsilah
- Code.gs                            Backend Google Apps Script
- appsscript.json                    Konfigurasi Apps Script
- Nasab_Syeikh_Ibrahim_Database_Template.xlsx  Template database

CARA TERCEPAT MEMBUAT WEBSITE PUBLIK
1. Buat repository GitHub baru, misalnya: nasab-syeikh-ibrahim
2. Upload index.html dan silsilah-referensi.jpeg.
3. Settings > Pages > Deploy from branch > pilih main / root.
4. Tunggu GitHub Pages aktif. URL akan berbentuk:
   https://USERNAME.github.io/nasab-syeikh-ibrahim/

CATATAN DATA
Website memiliki penyimpanan lokal (localStorage) dan dukungan Google Apps Script.
Jika ingin satu database yang sama untuk semua pengunjung/admin, gunakan Code.gs + Google Spreadsheet.
Jangan menaruh token rahasia secara permanen di source code publik.

BACKEND GOOGLE APPS SCRIPT
1. Buat Google Spreadsheet.
2. Extensions > Apps Script.
3. Tempel Code.gs.
4. Isi ACCESS_TOKEN dan ADMIN_PIN dengan nilai sendiri.
5. Deploy sebagai Web app.
6. Execute as: Me.
7. Atur akses sesuai kebutuhan keluarga.
8. Masukkan URL Web App dan token melalui Pengaturan website saat menjadi admin.

KEAMANAN
- Jangan membagikan ADMIN_PIN.
- Token API yang ditulis di browser dapat terlihat oleh pengguna yang memiliki akses ke aplikasi.
- Untuk data keluarga yang sensitif, pertimbangkan membatasi akses dan tidak menjadikan seluruh database terbuka untuk publik.
